/*Documentiation
  Sai Chandu
  29-10-24
  sample input:5
  sample output:1 2 3 4 5
                6     7
                8   9
                10 11
                12
*/
#include<stdio.h>
int main()
{
    int num,count=1;
    printf("Enter the number: ");
    scanf("%d",&num);
    for(int i=1;i<=num;i++)
    {
        for(int j=1;j<=num;j++)
        {
            if(i==1)
            {
                printf("%d ",j);
                count++;
            }
            else if(j==1)
            {
                printf("%d ",count);
                count++;
            }
            else if((i+j)==(num+1))
            {
                printf("%d ",count);
                count++;
            }
            else
            {
                printf("  ");
            }
        }
        printf("\n");
    }
}