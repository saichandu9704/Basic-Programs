/*Documentiation
  Sai Chandu
  29-10-24
  sample input:5
  sample output:1   5
                 2 4 
                  3  
                 2 4 
                1   5
*/
#include<stdio.h>
int main()
{
    int num;
    printf("Enter the number: ");
    scanf("%d",&num);
    if(num>2)
    {
        for(int i=1;i<=num;i++)
        {
            for(int j=1;j<=num;j++)
            {
                if((i==j) || (i+j==num+1))
                {
                    printf("%d",j);
                }
                else
                {
                    printf(" ");
                }
            }
            printf("\n");
        }
    }
    else
    {
        printf("Invalid number");
    }
}
